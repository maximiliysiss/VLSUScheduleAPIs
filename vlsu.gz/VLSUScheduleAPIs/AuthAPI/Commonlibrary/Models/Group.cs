﻿namespace CommonLibrary.Models
{
    public class Group
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}