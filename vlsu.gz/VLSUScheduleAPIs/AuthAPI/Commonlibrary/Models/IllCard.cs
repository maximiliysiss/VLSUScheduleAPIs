﻿using System;

namespace CommonLibrary.Models
{
    public class IllCard
    {
        public int ID { get; set; }
        public DateTime Date { get; set; }
        public Teacher Teacher { get; set; }
    }
}